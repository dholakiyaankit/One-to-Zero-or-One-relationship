namespace WebApplication1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class test : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cargoes",
                c => new
                    {
                        CargoID = c.Int(nullable: false, identity: true),
                        DateOfPassage = c.DateTime(nullable: false),
                        CompanyUserName = c.String(),
                    })
                .PrimaryKey(t => t.CargoID);
            
            CreateTable(
                "dbo.ContainerIns",
                c => new
                    {
                        ContainerInID = c.Int(nullable: false, identity: true),
                        LoadStatus = c.Int(nullable: false),
                        CargoID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ContainerInID)
                .ForeignKey("dbo.Cargoes", t => t.ContainerInID)
                .Index(t => t.ContainerInID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ContainerIns", "ContainerInID", "dbo.Cargoes");
            DropIndex("dbo.ContainerIns", new[] { "ContainerInID" });
            DropTable("dbo.ContainerIns");
            DropTable("dbo.Cargoes");
        }
    }
}
