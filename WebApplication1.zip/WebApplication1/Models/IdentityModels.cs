﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;

namespace WebApplication1.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }

    public class ApplicationDbContext : DbContext
    {

        public virtual DbSet<Cargo> Cargo { get; set; }
        public virtual DbSet<ContainerIn> ContainerIn { get; set; }

        public ApplicationDbContext()
            : base("DefaultConnection")
        {
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {           
            modelBuilder.Entity<Cargo>()
                        .HasOptional(s => s.CompanyUserNameContainIn) 
                        .WithRequired(ad => ad.Cargo); 
        }
        
    }

    public class Cargo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CargoID { get; set; }//SerialNo
        [Required]
        public DateTime DateOfPassage { get; set; }
        public string CompanyUserName { get; set; }
        public virtual ContainerIn CompanyUserNameContainIn { get; set; }
    }

    public class ContainerIn
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ContainerInID { get; set; }        
        public int LoadStatus { get; set; }        
        public int CargoID { get; set; }        
        public virtual Cargo Cargo { get; set; }
    }
}